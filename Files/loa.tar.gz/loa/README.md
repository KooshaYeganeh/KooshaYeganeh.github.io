# LoA

## Linux on Android - Transferring the functionality of Linux to Android

## AMD  : Andriod Malware Detect

    
## Info

This project is a part of the Lova project, which is responsible for securing the Android system.
The Leva project is a project based on simulating and working with GNU Linux on the Android shell, in which tools and methods have been tried to provide a development system for desktop developers, as well as to inform ordinary users about the Android system and tools and The work that can be done in the usual way has been started.
  In this regard, we are trying to use tools to optimize and improve the performance and performance of your system and files in Android.
The first phase is the AMD project, whose task is to detect corrupted files on your storage system using powerful Linux tools.
Statements developed to scan your system or posted on Android include:

**1 - clamAV**				
**2 - Yara**		
**3 - KYGnus**

This security system uses 3 separate engines to scan your files. The first engine is clamAV, which is one of the most powerful antivirus available and is widely installed on Linux servers.
The second engine is Yara, which security specialists use to check and categorize viruses.
The third engine is the engine developed by KYGnus, which is similar to the Linux scan engine, and it carefully checks the files and abnormal activities of your system.
You don't need any special skills to install this scanner.
Just install Termax on your Android device and copy this command and run it on your device.





## Install


```
wget https://gitlab.com/KooshaYeganeh/loa/-/archive/main/loa-main.zip && unzip loa-main.zip && cd loa-main && ./install
```



## remove

```
pkg remove clamav && sudo apt-get remove yara -y && cd && rm -rvf databases && rm -rvf loa
```


## contact

- [Gmail](kooshakooshadv@gmail.com)
- [website](kooshayeganeh.github.io)
- [Github](https://github.com/KooshaYeganeh/)
